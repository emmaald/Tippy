package com.example.tippy

import android.animation.ArgbEvaluator
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.SeekBar
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_main.*

private const val TAG = "MainActivity"
private const val INITIAL_TIP_PERCENT = 15

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        seekBarTip.progress = INITIAL_TIP_PERCENT
        TipPercent.text = "$INITIAL_TIP_PERCENT%"
        updateTipDesc(INITIAL_TIP_PERCENT)
        seekBarTip.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                 Log.i(TAG, "onProgressChanged $progress")
                TipPercent.text = "$progress%"
                updateTipDesc(progress)
                computeTipAndTotal()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        ETBase.addTextChangedListener(object: TextWatcher {
            override fun afterTextChanged(s: Editable?) {
              Log.i(TAG, "afterTextChanged $s")
              computeTipAndTotal()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

    }

    private fun updateTipDesc(tipPercent: Int) {
        val tipDesc : String
        when (tipPercent){
            in 0..9 -> tipDesc = "Student"
            in 10..14 -> tipDesc = "Acceptable"
            in 15..19 -> tipDesc = "Good"
            in 20..24 -> tipDesc = "Great"
            else -> tipDesc = "Amazing"

        }
        TVTipDesc.text = tipDesc
        val color = ArgbEvaluator().evaluate(tipPercent.toFloat()/seekBarTip.max,
            ContextCompat.getColor(this, R.color.colorWorstTip),
            ContextCompat.getColor(this, R.color.colorBestTip)
            ) as Int
        TVTipDesc.setTextColor(color)
    }

    private fun computeTipAndTotal() {
        //Get the value of base and tip percent
        if (ETBase.text.toString().isEmpty()){
            TVTipAmount.text = ""
            TVTotalAmount.text = ""
            return
        }
        val baseAmount = ETBase.text.toString().toDouble()
        val tipPercent = seekBarTip.progress
        val tipAmount = baseAmount*tipPercent /100
        val totalAmount = baseAmount+tipAmount
        TVTipAmount.text = "%.2f".format(tipAmount)
        TVTotalAmount.text = "%.2f".format(totalAmount)
    }
}
